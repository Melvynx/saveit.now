"use strict";(()=>{var S="https://saveit.now";var y="hidden",n="page",E="";async function h(){return new Promise(e=>{chrome.runtime.sendMessage({type:"GET_SESSION"},s=>{console.log("Content: Session response from background",s),e(s?.session||null)})})}async function p(e,s="page"){return new Promise(r=>{chrome.runtime.sendMessage({type:"SAVE_BOOKMARK",url:e,itemType:s},t=>{console.log("Content: Save response from background",t),r(t||{success:!1,error:"No response from background",itemType:s})})})}function o(e){switch(e){case"page":return"page";case"link":return"link";case"image":return"image";default:return"item"}}function c(){let e=document.createElement("div");return e.id="saveit-now-container",e.className="saveit-container hidden",e.innerHTML=`
    <div class="saveit-card">
      <div id="saveit-loading" class="saveit-state">
        <svg class="saveit-loader" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-loader-circle-icon lucide-loader-circle"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
        <div id="saveit-loading-message" class="saveit-message">Saving...</div>
      </div>
      
      <div id="saveit-success" class="saveit-state">
        <svg class="saveit-checkmark" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-icon lucide-check"><path d="M20 6 9 17l-5-5"/></svg>
        <div id="saveit-success-message" class="saveit-message">Page saved!</div>
      </div>
      
      <div id="saveit-error" class="saveit-state">
        <svg class="saveit-error" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-alert-icon lucide-circle-alert"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
        <div class="saveit-message" id="saveit-error-message">An error occurred</div>
      </div>
      
      <div id="saveit-auth" class="saveit-state saveit-auth-required">
        <div class="saveit-message">Connection required</div>
        <a href="${S}/signin" target="_blank" class="saveit-button">Login</a>
      </div>

      <div id="saveit-max-bookmarks" class="saveit-state saveit-auth-required">
        <div class="saveit-message">You've reached your bookmark limit</div>
        <a href="${S}/upgrade" target="_blank" class="saveit-button">Upgrade</a>
      </div>

      <div id="saveit-bookmark-exists" class="saveit-state">
        <svg class="saveit-error" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
        <div class="saveit-message">Bookmark already exists</div>
      </div>
    </div>
  `,document.body.appendChild(e),document.addEventListener("click",s=>{e&&!e.contains(s.target)&&y!=="hidden"&&a("hidden")}),e}function a(e){y=e;let s=document.getElementById("saveit-now-container");if(!s)return;switch(s.querySelectorAll(".saveit-state").forEach(t=>{t.style.display="none"}),e){case"hidden":s.classList.add("hidden");break;case"loading":s.classList.remove("hidden");let t=document.getElementById("saveit-loading");t&&(t.style.display="flex");let i=document.getElementById("saveit-loading-message");i&&(i.textContent=`Saving ${o(n)}...`);break;case"success":s.classList.remove("hidden");let d=document.getElementById("saveit-success");d&&(d.style.display="flex");let l=document.getElementById("saveit-success-message");l&&(l.textContent=`${o(n).charAt(0).toUpperCase()+o(n).slice(1)} saved!`),setTimeout(()=>{a("hidden")},2e3);break;case"error":s.classList.remove("hidden");let v=document.getElementById("saveit-error");v&&(v.style.display="flex");break;case"auth-required":s.classList.remove("hidden");let u=document.getElementById("saveit-auth");u&&(u.style.display="flex");break;case"max-bookmarks":s.classList.remove("hidden");let m=document.getElementById("saveit-max-bookmarks");m&&(m.style.display="flex");break;case"bookmark-exists":s.classList.remove("hidden");let g=document.getElementById("saveit-bookmark-exists");g&&(g.style.display="flex"),setTimeout(()=>{a("hidden")},3e3);break}}function k(e){let s=document.getElementById("saveit-error-message");s&&(s.textContent=e)}async function f(e,s="page"){try{if(n=s,E=e,a("loading"),!await h()){a("auth-required");return}let t=await p(e,s);if(t.success)a("success");else{let i=t.error||"Error saving bookmark";i.includes("maximum number of bookmarks")?a("max-bookmarks"):i.includes("already exists")?a("bookmark-exists"):(k(i),a("error"))}}catch(r){console.error("Error saving content:",r),k("An error occurred"),a("error")}}chrome.runtime.onMessage.addListener((e,s,r)=>{if(document.getElementById("saveit-now-container")===null&&c(),e.action==="saveBookmark"||e.action==="showSaveUI"){let t=e.type?e.type:"page",i=e.url||window.location.href;f(i,t),r({status:"received"})}});document.addEventListener("DOMContentLoaded",()=>{c()});(document.readyState==="complete"||document.readyState==="interactive")&&c();})();
