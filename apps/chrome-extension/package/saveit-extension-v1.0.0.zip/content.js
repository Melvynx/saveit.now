var l="http://localhost:3000";var u="hidden";async function g(){return new Promise(s=>{chrome.runtime.sendMessage({type:"GET_SESSION"},e=>{console.log("Content: Session response from background",e),s(e?.session||null)})})}async function k(s){return new Promise(e=>{chrome.runtime.sendMessage({type:"SAVE_BOOKMARK",url:s},a=>{console.log("Content: Save response from background",a),e(a||{success:!1,error:"No response from background"})})})}function m(){let s=document.createElement("div");return s.id="saveit-now-container",s.className="saveit-container hidden",s.innerHTML=`
    <div class="saveit-card">
      <div id="saveit-loading" class="saveit-state">
        <svg class="saveit-loader" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-loader-circle-icon lucide-loader-circle"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
        <div class="saveit-message">Saving...</div>
      </div>
      
      <div id="saveit-success" class="saveit-state">
        <svg class="saveit-checkmark" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-icon lucide-check"><path d="M20 6 9 17l-5-5"/></svg>
        <div class="saveit-message">Page saved!</div>
      </div>
      
      <div id="saveit-error" class="saveit-state">
        <svg class="saveit-error" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-alert-icon lucide-circle-alert"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
        <div class="saveit-message" id="saveit-error-message">An error occurred</div>
      </div>
      
      <div id="saveit-auth" class="saveit-state saveit-auth-required">
        <div class="saveit-message">Connection required</div>
        <a href="${l}/auth/signin" target="_blank" class="saveit-button">Login</a>
      </div>

      <div id="saveit-max-bookmarks" class="saveit-state saveit-auth-required">
        <div class="saveit-message">You've reached your bookmark limit</div>
        <a href="${l}/upgrade" target="_blank" class="saveit-button">Upgrade</a>
      </div>

      <div id="saveit-bookmark-exists" class="saveit-state">
        <svg class="saveit-error" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
        <div class="saveit-message">Bookmark already exists</div>
      </div>
    </div>
  `,document.body.appendChild(s),document.addEventListener("click",e=>{s&&!s.contains(e.target)&&u!=="hidden"&&t("hidden")}),s}function t(s){u=s;let e=document.getElementById("saveit-now-container");if(!e)return;switch(e.querySelectorAll(".saveit-state").forEach(r=>{r.style.display="none"}),s){case"hidden":e.classList.add("hidden");break;case"loading":e.classList.remove("hidden");let r=document.getElementById("saveit-loading");r&&(r.style.display="flex");break;case"success":e.classList.remove("hidden");let i=document.getElementById("saveit-success");i&&(i.style.display="flex"),setTimeout(()=>{t("hidden")},2e3);break;case"error":e.classList.remove("hidden");let o=document.getElementById("saveit-error");o&&(o.style.display="flex");break;case"auth-required":e.classList.remove("hidden");let n=document.getElementById("saveit-auth");n&&(n.style.display="flex");break;case"max-bookmarks":e.classList.remove("hidden");let c=document.getElementById("saveit-max-bookmarks");c&&(c.style.display="flex");break;case"bookmark-exists":e.classList.remove("hidden");let d=document.getElementById("saveit-bookmark-exists");d&&(d.style.display="flex"),setTimeout(()=>{t("hidden")},3e3);break}}function v(s){let e=document.getElementById("saveit-error-message");e&&(e.textContent=s)}async function S(){try{if(t("loading"),!await g()){t("auth-required");return}let e=await k(window.location.href);if(e.success)t("success");else{let a=e.error||"Error saving bookmark";a.includes("maximum number of bookmarks")?t("max-bookmarks"):a.includes("already exists")?t("bookmark-exists"):(v(a),t("error"))}}catch(s){console.error("Error saving bookmark:",s),v("An error occurred"),t("error")}}chrome.runtime.onMessage.addListener((s,e,a)=>{(s.action==="saveBookmark"||s.action==="showSaveUI")&&(S(),a({status:"received"}))});document.addEventListener("DOMContentLoaded",()=>{m()});(document.readyState==="complete"||document.readyState==="interactive")&&m();
